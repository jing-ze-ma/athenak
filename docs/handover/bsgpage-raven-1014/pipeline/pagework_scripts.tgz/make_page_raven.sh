#!/bin/bash
#SBATCH -J bsgpage
#SBATCH -p general
#SBATCH -N 1
#SBATCH -c 72
#SBATCH --mem=240000
#SBATCH -t 01:30:00
#SBATCH -o /raven/ptmp/jinma/bsgpage_1013/pagework/make_page.%j.out
# BP 10-13: BSG true-repro page from Raven bsgP (FIN3, 9972a56d), read only via the snapshot view
# /raven/ptmp/jinma/bsgpage_1013/view/P (symlinks to prod/P/bin dumps 0-42 + copied hst/logs at t = 20.6 d).
export W=/raven/ptmp/jinma/bsgpage_1013/pagework
PAGE=${1:-/raven/ptmp/jinma/bsgpage_1013/page}
source /etc/profile.d/modules.sh 2>/dev/null; module load ffmpeg/7.1 2>/dev/null
export PATH=/u/jinma/miniconda3/envs/magritte/bin:$PATH
export FFMPEG_MODULE=ffmpeg/7.1
export BSG_REPRO_RUN=/raven/ptmp/jinma/bsgpage_1013/view/P
export BSG_REPRO_FULL_RUN=$BSG_REPRO_RUN BSG_BUILD_MERGED=
export BSG_INP=bsgP_seed_fin3.athinput
export BSG_IC=/raven/ptmp/jinma/bsg_truerepro_1008/files/ic_ma2026_f0.txt
export BSG_OPAC=/raven/ptmp/jinma/bsg_truerepro_1008/files/rosseland_ma2026_x0.7_z0.008_padded.txt
export BSG_COST_PARTS=$W/parts.json
export BSG_RUN_LABEL='bsgP, 9972a56d'
export BSG_HW_LABEL='4 Raven nodes, 16 A100, 16 MeshBlocks (1 per GPU)'
export BSG_KE_LABEL='true reproduction run (10$^{-6}$ seed, FIN3)'
export MPLCONFIGDIR=$W/pipe/cache/mpl
mkdir -p $PAGE/img $PAGE/movie $MPLCONFIGDIR
python3 -c "import astropy, numpy, scipy, matplotlib; print('py ok', numpy.__version__)"
which ffmpeg
cp $W/pipe/index.html $PAGE/index.html
time bash $W/pipe/update_page_repro.sh $PAGE
