# Approximate 3x-solar premixed correlated-k tables for WASP-121b (2026-09-30)

Built from the Exo-FMS premixed tables (upstream https://github.com/ELeeAstro/Exo-FMS_column_ck,
cloned in `Exo-FMS_column_ck/`; its 1x and 10x files are byte-identical to our production
`data/exo_fms_ck` 1x and `wasp121_0925/ckdata10` 10x) by interpolation in log Z. Python only,
login node. Scripts in `scripts/`, outputs `scripts/*.out`.

## Method (adopted)

* **k-table:** ln(k/X) - the opacity per H nucleus - linear in log10 Z at fixed (T, P, band, g),
  between 1x and 10x; X = 1/(1 + Y/X + (Z/X)_sun Z), Asplund09 (Y/X = 0.2485/0.7381,
  (Z/X)_sun = 0.0134/0.7381). Plain ln k (per gram) is biased low by 25-30 % over 2 dex
  because the metal mass dilutes the per-gram opacity (mu 2.32 -> 4.43 from 1x to 100x).
  g-order is kept exactly (same weights on monotone rows); 1038 of 113696 entries lie at most
  0.028 in ln outside [k1x, k10x] (the X factor).
* **CE table:** mu linear in Z = 10^[M/H]; ln VMR of H2, He, H, e-, H- linear in log Z.
* Rejected: interpolating the cumulative k-distribution (g at fixed k, mixture of the two
  distributions): Rosseland-like means -80 %, Planck-like +150 % (validate.out, variant D).

## Validation (scripts/validate.out, scripts/sonora_test.out)

T 1000-4000 K, P 1e-6..100 bar. "grey" = band means combined with B_b(T) / dB_b/dT weights,
line opacity only (no CIA/Rayleigh/H-, so conservative). |err| median / 90 % / max.

| test | span | grey Planck | grey Rosseland | IR bands 2.02-20 um, band-mean Planck-like med/90 % | 4.4-3.5 um | optical 0.26-1.32 um |
|---|---|---|---|---|---|---|
| Exo-FMS 1x+100x -> 10x, ln k | 2 dex | 30 / 40 / 60 % (bias -29 %) | 30 / 39 / 53 % | ~27 / 35 % | 22 / 40 % | 27-40 / 54-76 % |
| Exo-FMS 1x+100x -> 10x, ln(k/X) | 2 dex | 8 / 22 / 45 % | 12 / 23 / 39 % | 1-7 / 13-27 % | 25 / 79 % | 5-28 / 52-75 % |
| Exo-FMS 1x+1000x -> 10x, ln(k/X) | 3 dex | 16 / 33 / 47 % | 19 / 35 / 56 % | | | |
| Exo-FMS 10x+1000x -> 100x, ln(k/X) | 2 dex | 9 / 21 / 39 % | 13 / 26 / 38 % | | | |
| **Sonora 0.0+1.0 -> 0.5, ln(k/X)** | **1 dex (our case)** | **1.1 / 5.6 / 9 %** | **2.9 / 7.9 / 31 %** | 0.6-0.8 / 3-7 % | 2.3 / 15 % | 1-6 / 9-15 % |
| no interpolation (1x for 3.16x), Sonora | | 68 % | 69 % | | | |

CE (Exo-FMS 1x+100x -> 10x, VMR mode): |d ln| H2/He/H <= 0.08, e-/H- median 0.08-0.10,
90 % 0.22-0.24, max 1.1; mu (linear in Z) 0.7 / 1.4 / 3 %. Sonora at exactly 1 dex:
H2/He/H <= 0.004, e-/H- 0.02 / 0.05 / 0.24, mu 0.4 % max. Direct FastChem 3x (gas phase,
`ce_fastchem_check.py`): the 3x table/FastChem ratio lies inside the 1x/10x spread at
<= 4000 K except e-/H- 3 % lower at 3500-4000 K; at 5000-6100 K e-/H- are up to 18 % high
(the log-Z curvature of the ionisation), which is also the CE ratio 1.17 that gen_hitemp.py
reports at 6100 K, P 0.01-0.2 bar (1x and 10x: <= 1.006).

**Verdict:** usable, with ln(k/X). Over 2 dex the Exo-FMS test gives grey medians 8-12 %
(90 % 22 %); the 3x build spans 1 dex, and the direct 1-dex test (Sonora, [M/H] = 0.5)
gives grey medians 1-3 %, 90 % < 8 %; the optical bands and 4.4-3.5 um carry the largest
per-band errors (90 % 11-15 %).

## Sonora 2020 cross-check (sonora/)

Lupu, Freedman & Visscher, "Correlated k coefficients for H2-He atmospheres; 11 spectral
windows and 1460 pressure-temperature points", Zenodo, doi:10.5281/zenodo.5590997 (CC-BY 4.0).
Files: sonora_2020_feh{+000,+050,+100}_co_100.data.11.tar.gz, 11_windows.txt.
* The 11 windows (30.8 ... 38300 cm-1) are the same Kataria/SPARC bands as
  wavelengths_GCM_11.txt (edges agree to 0.2 %), same 4+4 double-Gauss g (split 0.95).
* ascii_data layout (decoded here; `scripts/sonora_lib.py`): ln k in cm^2/molecule,
  per (T, P) 16 x 200 slots of which g 1-8 x window 1-11 are used, T outer (73, 75-4000 K),
  P inner (20, 1e-6..3000 bar, stored in mbar). Per gram: k/(mu amu), mu from full_abunds.
  Quirk: windows 0.61-0.42 and 0.42-0.26 um are identical in 22 % of the (T,P) points.
* Sonora 1x / Exo-FMS 1x (band means, common nodes 1000-3500 K, 1e-6..100 bar): IR bands
  1.1-1.7x higher in Sonora (median), optical 0.9-1.7x median with 10-90 % spread 0.06-6x;
  grey Planck 1.12 [0.69, 1.79], grey Rosseland 1.52 [0.52, 1.77]. The two opacity sets
  differ far more than the interpolation error.
* 10^0.5 / 1x band-mean ratio: Sonora (true) 3.03-3.18, Exo-FMS interpolated (1x+10x at
  [M/H] = 0.5) 2.86-3.13; grey 3.10 vs 3.03-3.06 (median |d ln| 0.03-0.04).
* Not used for production: T max 4000 K, P min 1e-6 bar, different line lists.

## Files: `ckdata3/` (same layout as wasp121_0925/ckdata10)

* `ck/Premixed_3x_g8_11.txt` (38 T x 34 P x 11 x 8, header = upstream 1x header),
  `ck/Premixed_3x_g8_11_hiT.txt`, `ck/Premixed_3x_g8_11_hiT2.txt` (use hiT2, nT 93);
* `CE_tables/FastChem_ck_3x_int.txt`, `_hiT.txt`, `_hiT2.txt` (nT 401 to 10100 K);
* symlinks `cia/ ray/ sw_flux/` -> repo data/exo_fms_ck.
Made by `scripts/build3x.py` (base) and `gen3.sh` (repo tools/gen_hitemp.py unchanged,
`--met 3x` and `--met 3x --v1`, CK_DATA = ckdata3, FASTCHEM_INPUT = `fc_in3` = Asplund09
metals +0.47712 dex, logK -> ckhitemp_0925). Logs gen3_hiT.log, gen3_hiT2.log.

Continuity (scripts/continuity.py): largest band-mean ln k jump 5900 -> 6100 K = 0.525
(1x 0.502, 10x 0.641); above 6100 K max node jump 0.80 in hiT2 (1x 0.85, 10x 0.75); CE ratio
upstream/FastChem at 6100 K 0.936-1.173 (1x 0.94-1.006, 10x 0.935-1.005); 74 g-monotonicity
fixes in the blend window (1x 161, 10x 183).

## EOS composition for 3x (Asplund09, solar He/H, Z/X = 3 x 0.018155)

`eos_xh = 0.7188`, `eos_yhe = 0.2420` (Z = 0.0392, Z/X = 0.0545); problem/met = 0.4771.
(10x for comparison: 0.6588 / 0.2218.) EOS dump not made.

## Caveats

* Approximate: the true 3x table would need a new premixed calculation; the validated error
  is the 1-dex interpolation error on Sonora (a different opacity set with the same bands) and
  the 2-dex error on Exo-FMS itself; neither tests Exo-FMS at 1 dex directly.
* Largest per-band errors in the optical (condensation of TiO/VO/Fe shifts with Z;
  worst near 1000-1900 K) and at 4.4-3.5 um (CO2, superlinear in Z).
* e-/H- at 5000-6100 K up to 18 % high (see above); H- continuum there scales with it.
