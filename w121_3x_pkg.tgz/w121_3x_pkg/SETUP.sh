#!/bin/bash
# usage: bash SETUP.sh <repo root (for data/exo_fms_ck)>   -> fills the template, links cia/ray/sw_flux
PKG=$(cd "$(dirname "$0")" && pwd); REPO=${1:?repo root}
for d in cia ray sw_flux; do ln -sfn "$REPO/data/exo_fms_ck/$d" "$PKG/ckdata3/$d"; done
sed "s#@PKG@#$PKG#g" "$PKG/w121prod_3x.athinput.template" > "$PKG/w121prod_3x.athinput"
echo "wrote $PKG/w121prod_3x.athinput"; grep -n "@PKG@" "$PKG/w121prod_3x.athinput" && echo "UNFILLED PLACEHOLDER" || true
